import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";
import { authTables } from "@convex-dev/auth/server";

const applicationTables = {
  users: defineTable({
    username: v.optional(v.string()),
    password: v.optional(v.string()),
    isAdmin: v.optional(v.boolean()),
    lastLogin: v.optional(v.number()),
    active: v.optional(v.boolean()),
    email: v.optional(v.string()),
  }).index("by_username", ["username"]),
  
  channels: defineTable({
    name: v.string(),
    logo: v.string(),
    url: v.string(),
    category: v.string(),
    isLive: v.boolean(),
    qualities: v.array(v.object({
      label: v.string(),
      url: v.string(),
    })),
  }).index("by_category", ["category"]),
};

export default defineSchema({
  ...authTables,
  ...applicationTables,
});
