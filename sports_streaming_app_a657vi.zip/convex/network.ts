"use node";
import { action } from "./_generated/server";
import { v } from "convex/values";

const ping = require('ping');

export const checkServers = action({
  args: {},
  handler: async (ctx) => {
    // التحقق من الخادم الأول
    const result1 = await ping.promise.probe('10.136.96.35', {
      timeout: 2,
    });

    if (result1.alive) {
      return { connected: true, server: '10.136.96.35' };
    }

    // التحقق من الخادم الثاني
    const result2 = await ping.promise.probe('10.136.96.195', {
      timeout: 2,
    });

    if (result2.alive) {
      return { connected: true, server: '10.136.96.195' };
    }

    return { connected: false, server: null };
  },
});
