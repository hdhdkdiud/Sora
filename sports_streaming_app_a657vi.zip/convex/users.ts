import { v } from "convex/values";
import { mutation, query } from "./_generated/server";
import { getAuthUserId } from "@convex-dev/auth/server";

export const createUser = mutation({
  args: {
    username: v.string(),
    password: v.string(),
  },
  handler: async (ctx, args) => {
    const currentUser = await getAuthUserId(ctx);
    if (!currentUser) throw new Error("Unauthorized");
    
    const admin = await ctx.db
      .query("users")
      .withIndex("by_username", (q) => q.eq("username", "1"))
      .unique();
    
    if (!admin || admin._id !== currentUser || !admin.isAdmin) {
      throw new Error("Only admin can create users");
    }

    const existing = await ctx.db
      .query("users")
      .withIndex("by_username", (q) => q.eq("username", args.username))
      .unique();
    
    if (existing) throw new Error("Username already exists");

    await ctx.db.insert("users", {
      username: args.username,
      password: args.password,
      isAdmin: false,
      active: true,
    });
  },
});

export const deleteUser = mutation({
  args: {
    userId: v.id("users"),
  },
  handler: async (ctx, args) => {
    const currentUser = await getAuthUserId(ctx);
    if (!currentUser) throw new Error("Unauthorized");
    
    const admin = await ctx.db.get(currentUser);
    if (!admin?.isAdmin) throw new Error("Only admin can delete users");

    await ctx.db.patch(args.userId, { active: false });
  },
});

export const updateUser = mutation({
  args: {
    userId: v.id("users"),
    username: v.string(),
    password: v.string(),
  },
  handler: async (ctx, args) => {
    const currentUser = await getAuthUserId(ctx);
    if (!currentUser) throw new Error("Unauthorized");
    
    const admin = await ctx.db.get(currentUser);
    if (!admin?.isAdmin) throw new Error("Only admin can update users");

    await ctx.db.patch(args.userId, {
      username: args.username,
      password: args.password,
    });
  },
});

export const listUsers = query({
  handler: async (ctx) => {
    const currentUser = await getAuthUserId(ctx);
    if (!currentUser) throw new Error("Unauthorized");
    
    const admin = await ctx.db.get(currentUser);
    if (!admin?.isAdmin) throw new Error("Only admin can list users");

    return await ctx.db
      .query("users")
      .filter((q) => q.eq(q.field("active"), true))
      .collect();
  },
});

export const login = mutation({
  args: {
    username: v.string(),
    password: v.string(),
  },
  handler: async (ctx, args) => {
    const user = await ctx.db
      .query("users")
      .withIndex("by_username", (q) => q.eq("username", args.username))
      .filter((q) => 
        q.and(
          q.eq(q.field("password"), args.password),
          q.eq(q.field("active"), true)
        )
      )
      .unique();

    if (!user) throw new Error("Invalid credentials");
    
    await ctx.db.patch(user._id, {
      lastLogin: Date.now(),
    });
    
    return user;
  },
});

// Create initial admin user if not exists
export const initAdmin = mutation({
  args: {},
  handler: async (ctx) => {
    const admin = await ctx.db
      .query("users")
      .withIndex("by_username", (q) => q.eq("username", "1"))
      .unique();
    
    if (!admin) {
      await ctx.db.insert("users", {
        username: "1",
        password: "2",
        isAdmin: true,
        active: true,
      });
    }
  },
});
