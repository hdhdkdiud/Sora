import { useState } from 'react';

const BEIN_CHANNELS = [
  {
    id: 1,
    name: "beIN SPORTS 1 Premium",
    logo: "/bein1.png",
    url: "http://ugeen.live:8080/Ugeen_DTB8vj/BLPjAa/3221",
    category: "Premium"
  },
  {
    id: 2,
    name: "beIN SPORTS 2 Premium",
    logo: "/bein2.png",
    url: "http://ugeen.live:8080/Ugeen_DTB8vj/BLPjAa/3222",
    category: "Premium"
  },
  {
    id: 3,
    name: "beIN SPORTS 3 Premium",
    logo: "/bein3.png",
    url: "http://ugeen.live:8080/Ugeen_DTB8vj/BLPjAa/3224",
    category: "Premium"
  },
  {
    id: 4,
    name: "beIN SPORTS 4",
    logo: "/bein4.png",
    url: "http://ugeen.live:8080/Ugeen_DTB8vj/BLPjAa/3225",
    category: "Sports"
  },
  {
    id: 5,
    name: "beIN SPORTS 5",
    logo: "/bein5.png",
    url: "http://ugeen.live:8080/Ugeen_DTB8vj/BLPjAa/3226",
    category: "Sports"
  },
  {
    id: 6,
    name: "beIN SPORTS 6",
    logo: "/bein6.png",
    url: "http://ugeen.live:8080/Ugeen_DTB8vj/BLPjAa/3227",
    category: "Sports"
  },
  {
    id: 7,
    name: "beIN SPORTS 7",
    logo: "/bein7.png",
    url: "http://ugeen.live:8080/Ugeen_DTB8vj/BLPjAa/3228",
    category: "Sports"
  },
  {
    id: 8,
    name: "beIN SPORTS 8",
    logo: "/bein8.png",
    url: "http://ugeen.live:8080/Ugeen_DTB8vj/BLPjAa/3230",
    category: "Sports"
  },
  {
    id: 9,
    name: "beIN SPORTS 9",
    logo: "/bein9.png",
    url: "http://ugeen.live:8080/Ugeen_DTB8vj/BLPjAa/4033",
    category: "Sports"
  }
];

interface ChannelListProps {
  onChannelSelect: (url: string, name: string) => void;
}

export function ChannelList({ onChannelSelect }: ChannelListProps) {
  const [selectedChannel, setSelectedChannel] = useState<number | null>(null);
  const [selectedCategory, setSelectedCategory] = useState<string>("all");

  const categories = ["all", ...new Set(BEIN_CHANNELS.map(channel => channel.category))];
  
  const filteredChannels = selectedCategory === "all" 
    ? BEIN_CHANNELS 
    : BEIN_CHANNELS.filter(channel => channel.category === selectedCategory);

  return (
    <div className="space-y-6">
      <div className="flex gap-2 overflow-x-auto pb-2">
        {categories.map(category => (
          <button
            key={category}
            onClick={() => setSelectedCategory(category)}
            className={`px-4 py-2 rounded-full text-sm font-medium transition-colors whitespace-nowrap
              ${selectedCategory === category 
                ? 'bg-blue-600 text-white' 
                : 'bg-gray-700 text-gray-300 hover:bg-gray-600'}`}
          >
            {category === "all" ? "جميع القنوات" : category}
          </button>
        ))}
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
        {filteredChannels.map((channel) => (
          <button
            key={channel.id}
            onClick={() => {
              setSelectedChannel(channel.id);
              onChannelSelect(channel.url, channel.name);
            }}
            className={`group relative flex flex-col items-center p-4 rounded-xl transition-all
              ${selectedChannel === channel.id
                ? 'bg-blue-600 ring-2 ring-blue-400'
                : 'bg-gray-700/50 hover:bg-gray-700'}`}
          >
            <div className="w-20 h-20 flex items-center justify-center mb-3 relative">
              <div className="absolute inset-0 bg-blue-500/10 rounded-full group-hover:bg-blue-500/20 transition-colors" />
              <img
                src={channel.logo}
                alt={channel.name}
                className="max-w-full max-h-full object-contain relative z-10"
                onError={(e) => {
                  e.currentTarget.src = 'https://placehold.co/80x80?text=No+Image';
                }}
              />
            </div>
            <span className="text-sm font-medium text-center text-white group-hover:text-blue-200 transition-colors">
              {channel.name}
            </span>
            <span className="text-xs text-gray-400 mt-1">{channel.category}</span>
          </button>
        ))}
      </div>
    </div>
  );
}
