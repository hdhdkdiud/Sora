import { useEffect, useRef, useState } from 'react';
import Hls from 'hls.js';

interface VideoPlayerProps {
  src: string;
}

export function VideoPlayer({ src }: VideoPlayerProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const hlsRef = useRef<Hls | null>(null);
  const [currentQuality, setCurrentQuality] = useState<string>('auto');
  const [qualities, setQualities] = useState<Array<{ label: string; url: string }>>([]);
  const [isBuffering, setIsBuffering] = useState(true);

  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;

    const cleanup = () => {
      if (hlsRef.current) {
        hlsRef.current.destroy();
        hlsRef.current = null;
      }
      video.src = '';
      video.load();
    };

    cleanup();

    if (Hls.isSupported()) {
      const hls = new Hls({
        enableWorker: true,
        lowLatencyMode: true,
        backBufferLength: 90,
        maxBufferLength: 30,
        maxMaxBufferLength: 600,
        maxBufferSize: 60 * 1000 * 1000,
        maxBufferHole: 0.5,
        highBufferWatchdogPeriod: 2,
        nudgeOffset: 0.1,
        nudgeMaxRetry: 5,
      });
      
      hlsRef.current = hls;
      hls.loadSource(src);
      hls.attachMedia(video);
      
      hls.on(Hls.Events.MANIFEST_PARSED, (event, data) => {
        const levels = data.levels.map((level, index) => ({
          label: `${level.height}p`,
          url: level.url[0],
        }));
        setQualities([{ label: 'auto', url: src }, ...levels]);
        video.play().catch(() => {
          console.log('Autoplay prevented');
        });
      });

      hls.on(Hls.Events.ERROR, (event, data) => {
        if (data.fatal) {
          switch (data.type) {
            case Hls.ErrorTypes.NETWORK_ERROR:
              console.log('Network error, trying to recover...');
              hls.startLoad();
              break;
            case Hls.ErrorTypes.MEDIA_ERROR:
              console.log('Media error, trying to recover...');
              hls.recoverMediaError();
              break;
            default:
              cleanup();
              break;
          }
        }
      });

      video.addEventListener('waiting', () => setIsBuffering(true));
      video.addEventListener('playing', () => setIsBuffering(false));

      return cleanup;
    } else if (video.canPlayType('application/vnd.apple.mpegurl')) {
      video.src = src;
      video.addEventListener('loadedmetadata', () => {
        video.play().catch(() => {
          console.log('Autoplay prevented');
        });
      });

      return cleanup;
    }
  }, [src]);

  const handleQualityChange = (quality: string) => {
    if (!hlsRef.current) return;
    
    const levelIndex = qualities.findIndex(q => q.label === quality);
    hlsRef.current.currentLevel = quality === 'auto' ? -1 : levelIndex - 1;
    setCurrentQuality(quality);
  };

  return (
    <div className="relative w-full pt-[56.25%] bg-black">
      {isBuffering && (
        <div className="absolute inset-0 flex items-center justify-center bg-black/50">
          <div className="animate-spin rounded-full h-12 w-12 border-4 border-blue-500 border-t-transparent"></div>
        </div>
      )}
      <video
        ref={videoRef}
        className="absolute top-0 left-0 w-full h-full"
        controls
        playsInline
        poster="/channel-loading.png"
      />
      {qualities.length > 1 && (
        <div className="absolute bottom-16 right-4 bg-black/80 rounded-lg p-2">
          <select
            value={currentQuality}
            onChange={(e) => handleQualityChange(e.target.value)}
            className="bg-transparent text-white border border-gray-600 rounded px-2 py-1"
          >
            {qualities.map((quality) => (
              <option key={quality.label} value={quality.label}>
                {quality.label}
              </option>
            ))}
          </select>
        </div>
      )}
    </div>
  );
}
