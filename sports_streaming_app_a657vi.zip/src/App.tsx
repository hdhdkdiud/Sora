import { Authenticated, Unauthenticated } from "convex/react";
import { SignInForm } from "./SignInForm";
import { SignOutButton } from "./SignOutButton";
import { VideoPlayer } from "./VideoPlayer";
import { ChannelList } from "./ChannelList";
import { UserManagement } from "./UserManagement";
import { useState, useEffect } from "react";
import { useQuery, useMutation } from "convex/react";
import { api } from "../convex/_generated/api";

export default function App() {
  const [currentChannel, setCurrentChannel] = useState<string | null>(null);
  const [currentChannelName, setCurrentChannelName] = useState<string>("");
  const [connectionStatus, setConnectionStatus] = useState<{
    checking: boolean;
    connected: boolean;
    server: string | null;
  }>({
    checking: true,
    connected: false,
    server: null
  });
  const user = useQuery(api.auth.loggedInUser);

  useEffect(() => {
    const checkConnection = async () => {
      setConnectionStatus(prev => ({ ...prev, checking: true }));
      try {
        const result = await fetch("http://localhost:3000/api/checkServers");
        const data = await result.json();
        setConnectionStatus({
          checking: false,
          connected: data.connected,
          server: data.server
        });
      } catch (error) {
        setConnectionStatus({
          checking: false,
          connected: false,
          server: null
        });
      }
    };

    checkConnection();
    const interval = setInterval(checkConnection, 30000);
    return () => clearInterval(interval);
  }, []);

  if (connectionStatus.checking) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-gray-900 to-gray-800">
        <div className="text-center text-white">
          <div className="animate-spin rounded-full h-12 w-12 border-4 border-blue-500 border-t-transparent mx-auto mb-4"></div>
          <h1 className="text-2xl font-bold mb-2">جاري فحص الاتصال</h1>
          <p className="text-gray-400">يرجى الانتظار...</p>
        </div>
      </div>
    );
  }

  if (!connectionStatus.connected) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-gray-900 to-gray-800">
        <div className="text-center text-white max-w-md mx-auto p-6 bg-gray-800/50 rounded-xl">
          <div className="bg-red-500/10 rounded-full p-4 mb-4 mx-auto w-16 h-16 flex items-center justify-center">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-red-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
            </svg>
          </div>
          <h1 className="text-2xl font-bold mb-4">لا يمكن الوصول إلى الخدمة</h1>
          <p className="text-gray-400 mb-6">
            تعذر الاتصال بالخوادم المتاحة. يرجى التحقق من اتصالك بالشبكة والمحاولة مرة أخرى.
          </p>
          <button
            onClick={() => window.location.reload()}
            className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
          >
            إعادة المحاولة
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-br from-gray-900 to-gray-800">
      <header className="sticky top-0 z-10 bg-black/80 backdrop-blur-sm p-4 flex justify-between items-center border-b border-gray-700">
        <div className="flex items-center gap-2">
          <img src="/logo.png" alt="BeIN Sports" className="h-8 w-auto" />
          <h2 className="text-xl font-bold text-white">BeIN Sports TV</h2>
        </div>
        <div className="flex items-center gap-4">
          <div className="text-sm text-green-500 flex items-center gap-2">
            <span className="inline-block w-2 h-2 bg-green-500 rounded-full"></span>
            متصل بالخادم: {connectionStatus.server}
          </div>
          {user?.isAdmin && (
            <button
              onClick={() => {/* Toggle user management modal */}}
              className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
            >
              إدارة المستخدمين
            </button>
          )}
          <Authenticated>
            <SignOutButton />
          </Authenticated>
        </div>
      </header>

      <main className="flex-1 container mx-auto px-4 py-6">
        <Authenticated>
          <div className="space-y-6">
            {currentChannel ? (
              <div className="rounded-xl overflow-hidden shadow-2xl bg-black">
                <VideoPlayer key={currentChannel} src={currentChannel} />
                <div className="p-4">
                  <h3 className="text-xl font-semibold text-white">{currentChannelName}</h3>
                </div>
              </div>
            ) : (
              <div className="text-center py-12">
                <h3 className="text-2xl font-semibold text-white mb-2">مرحباً بك في BeIN Sports</h3>
                <p className="text-gray-400">اختر قناة للمشاهدة</p>
              </div>
            )}
            
            <div className="bg-gray-800/50 rounded-xl p-6">
              <h3 className="text-xl font-semibold text-white mb-4">القنوات المتاحة</h3>
              <ChannelList 
                onChannelSelect={(url, name) => {
                  setCurrentChannel(url);
                  setCurrentChannelName(name);
                }} 
              />
            </div>
          </div>
        </Authenticated>
        
        <Unauthenticated>
          <div className="max-w-md mx-auto mt-20 p-6 bg-gray-800/50 rounded-xl">
            <div className="text-center mb-8">
              <img src="/logo.png" alt="BeIN Sports" className="h-16 w-auto mx-auto mb-4" />
              <h1 className="text-3xl font-bold text-white mb-2">
                مرحباً بك في BeIN Sports TV
              </h1>
              <p className="text-gray-400">سجل دخولك لمشاهدة القنوات المباشرة</p>
            </div>
            <SignInForm />
          </div>
        </Unauthenticated>
      </main>

      <footer className="bg-black/80 text-gray-400 text-center py-4 mt-auto">
        <p className="text-sm">© 2024 BeIN Sports TV. جميع الحقوق محفوظة</p>
      </footer>
    </div>
  );
}
